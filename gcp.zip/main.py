from telegram_bot import bot

if __name__ == '__main__':
    bot.infinity_polling()